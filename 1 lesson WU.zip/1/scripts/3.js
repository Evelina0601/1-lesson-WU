let time = 2;
let speedOfFirst = 95;
let speedOfSecond = 114;
let distance = (speedOfFirst + speedOfSecond)* time;
console.log(distance);