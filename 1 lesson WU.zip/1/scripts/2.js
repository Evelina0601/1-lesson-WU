let height = 40;
let width = 70;
let result = height*width;
console.log(result);