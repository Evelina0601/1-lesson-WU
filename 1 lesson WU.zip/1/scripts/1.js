let city = 'Minsk';
let country = "Belarus";
let population = 2009786;
let stadion = true;
console.log(typeof city);